﻿namespace IndicateReport
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblSetPlan = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblActual = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.labelBalenced = new System.Windows.Forms.Label();
            this.lblBalenced = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.lookUpEdit1 = new DevExpress.XtraEditors.LookUpEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.panelContainer = new System.Windows.Forms.Panel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.textEditOvertime = new DevExpress.XtraEditors.TextEdit();
            this.textEditTime16_17 = new DevExpress.XtraEditors.TextEdit();
            this.textEditTime14_16 = new DevExpress.XtraEditors.TextEdit();
            this.textEditTime13_14 = new DevExpress.XtraEditors.TextEdit();
            this.textEditTime12_13 = new DevExpress.XtraEditors.TextEdit();
            this.textEditTime9_11 = new DevExpress.XtraEditors.TextEdit();
            this.textEditTime9_9_30 = new DevExpress.XtraEditors.TextEdit();
            this.lblOvertime = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.ThucTe_8 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.ThucTe_9 = new System.Windows.Forms.Label();
            this.ThucTe_940 = new System.Windows.Forms.Label();
            this.ThucTe_12 = new System.Windows.Forms.Label();
            this.ThucTe_13 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.ThucTe_14 = new System.Windows.Forms.Label();
            this.ThucTe_16 = new System.Windows.Forms.Label();
            this.ThucTe_Overtime = new System.Windows.Forms.Label();
            this.ChenhLech8 = new System.Windows.Forms.Label();
            this.ChenhLech9 = new System.Windows.Forms.Label();
            this.ChenhLech940 = new System.Windows.Forms.Label();
            this.ChenhLech12 = new System.Windows.Forms.Label();
            this.ChenhLech13 = new System.Windows.Forms.Label();
            this.ChenhLech14 = new System.Windows.Forms.Label();
            this.ChenhLech16 = new System.Windows.Forms.Label();
            this.ChenhLechOvertime = new System.Windows.Forms.Label();
            this.textEditTime8_9 = new DevExpress.XtraEditors.TextEdit();
            this.panel8 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.lblModelName = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.lblOperatorWip23 = new System.Windows.Forms.Label();
            this.panel19 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel12 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.lblTotalNGWip23 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.lblNotGoodWip23 = new System.Windows.Forms.Label();
            this.lblPassWip23 = new System.Windows.Forms.Label();
            this.lblTotalWip23 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lblProcessWip23 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.lblOperatorWip21 = new System.Windows.Forms.Label();
            this.panel22 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel14 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.label4 = new System.Windows.Forms.Label();
            this.lblTotalNGWip21 = new System.Windows.Forms.Label();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.lblNotGoodWip21 = new System.Windows.Forms.Label();
            this.lblPassWip21 = new System.Windows.Forms.Label();
            this.lblTotalWip21 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.lblProcessWip21 = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.lblOperatorWip22 = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.lblTotalNGWip22 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.lblNotGoodWip22 = new System.Windows.Forms.Label();
            this.lblPassWip22 = new System.Windows.Forms.Label();
            this.lblTotalWip22 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblProcessWip22 = new System.Windows.Forms.Label();
            this.timerRunAuto = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit1.Properties)).BeginInit();
            this.panelContainer.SuspendLayout();
            this.panel26.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textEditOvertime.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditTime16_17.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditTime14_16.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditTime13_14.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditTime12_13.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditTime9_11.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditTime9_9_30.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditTime8_9.Properties)).BeginInit();
            this.panel8.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.panel7.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel12.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.panel15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel13.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel22.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel14.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.panel16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel9.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel10.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(559, 77);
            this.label1.TabIndex = 11;
            this.label1.Text = "Customer: Canon";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label3.Location = new System.Drawing.Point(3, 141);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(210, 79);
            this.label3.TabIndex = 3;
            this.label3.Text = "Set Plan:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblSetPlan
            // 
            this.lblSetPlan.BackColor = System.Drawing.Color.White;
            this.lblSetPlan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSetPlan.Font = new System.Drawing.Font("DS-Digital", 50F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSetPlan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblSetPlan.Location = new System.Drawing.Point(219, 141);
            this.lblSetPlan.Name = "lblSetPlan";
            this.lblSetPlan.Size = new System.Drawing.Size(371, 79);
            this.lblSetPlan.TabIndex = 4;
            this.lblSetPlan.Text = "750";
            this.lblSetPlan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 35F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Green;
            this.label5.Location = new System.Drawing.Point(3, 73);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(210, 68);
            this.label5.TabIndex = 5;
            this.label5.Text = "Actual:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblActual
            // 
            this.lblActual.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblActual.Font = new System.Drawing.Font("DS-Digital", 50F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblActual.ForeColor = System.Drawing.Color.Green;
            this.lblActual.Location = new System.Drawing.Point(3, 0);
            this.lblActual.Name = "lblActual";
            this.lblActual.Size = new System.Drawing.Size(156, 62);
            this.lblActual.TabIndex = 5;
            this.lblActual.Text = "0";
            this.lblActual.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // progressBar1
            // 
            this.progressBar1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.progressBar1.Location = new System.Drawing.Point(165, 3);
            this.progressBar1.Maximum = 900;
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(203, 56);
            this.progressBar1.Step = 5;
            this.progressBar1.TabIndex = 1;
            this.progressBar1.Value = 5;
            // 
            // labelBalenced
            // 
            this.labelBalenced.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelBalenced.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBalenced.ForeColor = System.Drawing.Color.Red;
            this.labelBalenced.Location = new System.Drawing.Point(3, 220);
            this.labelBalenced.Name = "labelBalenced";
            this.labelBalenced.Size = new System.Drawing.Size(210, 73);
            this.labelBalenced.TabIndex = 7;
            this.labelBalenced.Text = "Balenced:";
            this.labelBalenced.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblBalenced
            // 
            this.lblBalenced.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblBalenced.Font = new System.Drawing.Font("DS-Digital", 50F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBalenced.ForeColor = System.Drawing.Color.Red;
            this.lblBalenced.Location = new System.Drawing.Point(219, 220);
            this.lblBalenced.Name = "lblBalenced";
            this.lblBalenced.Size = new System.Drawing.Size(371, 73);
            this.lblBalenced.TabIndex = 21;
            this.lblBalenced.Text = "-750";
            this.lblBalenced.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tableLayoutPanel6);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1130, 77);
            this.panel1.TabIndex = 1;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 2;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.panel3, 1, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(1130, 77);
            this.tableLayoutPanel6.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.tableLayoutPanel7);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(568, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(559, 71);
            this.panel3.TabIndex = 12;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 2;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel7.Controls.Add(this.lookUpEdit1, 1, 0);
            this.tableLayoutPanel7.Controls.Add(this.labelControl1, 0, 0);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 1;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(559, 71);
            this.tableLayoutPanel7.TabIndex = 0;
            // 
            // lookUpEdit1
            // 
            this.lookUpEdit1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lookUpEdit1.Location = new System.Drawing.Point(177, 10);
            this.lookUpEdit1.Margin = new System.Windows.Forms.Padding(10);
            this.lookUpEdit1.Name = "lookUpEdit1";
            this.lookUpEdit1.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 26F);
            this.lookUpEdit1.Properties.Appearance.Options.UseFont = true;
            this.lookUpEdit1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEdit1.Properties.NullText = "";
            this.lookUpEdit1.Properties.NullValuePrompt = "Select line";
            this.lookUpEdit1.Properties.NullValuePromptShowForEmptyValue = true;
            this.lookUpEdit1.Size = new System.Drawing.Size(372, 48);
            this.lookUpEdit1.TabIndex = 0;
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Tahoma", 30F, System.Drawing.FontStyle.Bold);
            this.labelControl1.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelControl1.Location = new System.Drawing.Point(3, 3);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(161, 65);
            this.labelControl1.TabIndex = 1;
            this.labelControl1.Text = "LINE:";
            // 
            // panelContainer
            // 
            this.panelContainer.Controls.Add(this.panel26);
            this.panelContainer.Controls.Add(this.panel8);
            this.panelContainer.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelContainer.Location = new System.Drawing.Point(0, 77);
            this.panelContainer.Name = "panelContainer";
            this.panelContainer.Size = new System.Drawing.Size(1130, 293);
            this.panelContainer.TabIndex = 3;
            // 
            // panel26
            // 
            this.panel26.Controls.Add(this.tableLayoutPanel5);
            this.panel26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel26.Location = new System.Drawing.Point(593, 0);
            this.panel26.Name = "panel26";
            this.panel26.Padding = new System.Windows.Forms.Padding(10);
            this.panel26.Size = new System.Drawing.Size(537, 293);
            this.panel26.TabIndex = 6;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel5.ColumnCount = 4;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel5.Controls.Add(this.textEditOvertime, 1, 8);
            this.tableLayoutPanel5.Controls.Add(this.textEditTime16_17, 1, 7);
            this.tableLayoutPanel5.Controls.Add(this.textEditTime14_16, 1, 6);
            this.tableLayoutPanel5.Controls.Add(this.textEditTime13_14, 1, 5);
            this.tableLayoutPanel5.Controls.Add(this.textEditTime12_13, 1, 4);
            this.tableLayoutPanel5.Controls.Add(this.textEditTime9_11, 1, 3);
            this.tableLayoutPanel5.Controls.Add(this.textEditTime9_9_30, 1, 2);
            this.tableLayoutPanel5.Controls.Add(this.lblOvertime, 0, 8);
            this.tableLayoutPanel5.Controls.Add(this.label17, 3, 0);
            this.tableLayoutPanel5.Controls.Add(this.label13, 2, 0);
            this.tableLayoutPanel5.Controls.Add(this.label12, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.label11, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.label18, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.label19, 0, 2);
            this.tableLayoutPanel5.Controls.Add(this.ThucTe_8, 2, 1);
            this.tableLayoutPanel5.Controls.Add(this.label20, 0, 3);
            this.tableLayoutPanel5.Controls.Add(this.ThucTe_9, 2, 2);
            this.tableLayoutPanel5.Controls.Add(this.ThucTe_940, 2, 3);
            this.tableLayoutPanel5.Controls.Add(this.ThucTe_12, 2, 4);
            this.tableLayoutPanel5.Controls.Add(this.ThucTe_13, 2, 5);
            this.tableLayoutPanel5.Controls.Add(this.label32, 0, 4);
            this.tableLayoutPanel5.Controls.Add(this.label33, 0, 5);
            this.tableLayoutPanel5.Controls.Add(this.label34, 0, 6);
            this.tableLayoutPanel5.Controls.Add(this.label35, 0, 7);
            this.tableLayoutPanel5.Controls.Add(this.ThucTe_14, 2, 6);
            this.tableLayoutPanel5.Controls.Add(this.ThucTe_16, 2, 7);
            this.tableLayoutPanel5.Controls.Add(this.ThucTe_Overtime, 2, 8);
            this.tableLayoutPanel5.Controls.Add(this.ChenhLech8, 3, 1);
            this.tableLayoutPanel5.Controls.Add(this.ChenhLech9, 3, 2);
            this.tableLayoutPanel5.Controls.Add(this.ChenhLech940, 3, 3);
            this.tableLayoutPanel5.Controls.Add(this.ChenhLech12, 3, 4);
            this.tableLayoutPanel5.Controls.Add(this.ChenhLech13, 3, 5);
            this.tableLayoutPanel5.Controls.Add(this.ChenhLech14, 3, 6);
            this.tableLayoutPanel5.Controls.Add(this.ChenhLech16, 3, 7);
            this.tableLayoutPanel5.Controls.Add(this.ChenhLechOvertime, 3, 8);
            this.tableLayoutPanel5.Controls.Add(this.textEditTime8_9, 1, 1);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(10, 10);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 9;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(517, 273);
            this.tableLayoutPanel5.TabIndex = 5;
            // 
            // textEditOvertime
            // 
            this.textEditOvertime.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textEditOvertime.Location = new System.Drawing.Point(209, 247);
            this.textEditOvertime.Name = "textEditOvertime";
            this.textEditOvertime.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.textEditOvertime.Properties.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.textEditOvertime.Properties.Appearance.Options.UseFont = true;
            this.textEditOvertime.Properties.Appearance.Options.UseForeColor = true;
            this.textEditOvertime.Properties.Appearance.Options.UseTextOptions = true;
            this.textEditOvertime.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.textEditOvertime.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.textEditOvertime.Properties.Mask.EditMask = "n0";
            this.textEditOvertime.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEditOvertime.Properties.NullText = "0";
            this.textEditOvertime.Size = new System.Drawing.Size(96, 24);
            this.textEditOvertime.TabIndex = 43;
            // 
            // textEditTime16_17
            // 
            this.textEditTime16_17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textEditTime16_17.EditValue = "89/750";
            this.textEditTime16_17.Location = new System.Drawing.Point(209, 218);
            this.textEditTime16_17.Name = "textEditTime16_17";
            this.textEditTime16_17.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.textEditTime16_17.Properties.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.textEditTime16_17.Properties.Appearance.Options.UseFont = true;
            this.textEditTime16_17.Properties.Appearance.Options.UseForeColor = true;
            this.textEditTime16_17.Properties.Appearance.Options.UseTextOptions = true;
            this.textEditTime16_17.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.textEditTime16_17.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.textEditTime16_17.Properties.Mask.EditMask = "n0";
            this.textEditTime16_17.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEditTime16_17.Properties.NullText = "0";
            this.textEditTime16_17.Size = new System.Drawing.Size(96, 24);
            this.textEditTime16_17.TabIndex = 42;
            // 
            // textEditTime14_16
            // 
            this.textEditTime14_16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textEditTime14_16.EditValue = "97/661";
            this.textEditTime14_16.Location = new System.Drawing.Point(209, 190);
            this.textEditTime14_16.Name = "textEditTime14_16";
            this.textEditTime14_16.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.textEditTime14_16.Properties.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.textEditTime14_16.Properties.Appearance.Options.UseFont = true;
            this.textEditTime14_16.Properties.Appearance.Options.UseForeColor = true;
            this.textEditTime14_16.Properties.Appearance.Options.UseTextOptions = true;
            this.textEditTime14_16.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.textEditTime14_16.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.textEditTime14_16.Properties.Mask.EditMask = "n0";
            this.textEditTime14_16.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEditTime14_16.Properties.NullText = "0";
            this.textEditTime14_16.Size = new System.Drawing.Size(96, 24);
            this.textEditTime14_16.TabIndex = 41;
            // 
            // textEditTime13_14
            // 
            this.textEditTime13_14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textEditTime13_14.EditValue = "129/564";
            this.textEditTime13_14.Location = new System.Drawing.Point(209, 162);
            this.textEditTime13_14.Name = "textEditTime13_14";
            this.textEditTime13_14.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.textEditTime13_14.Properties.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.textEditTime13_14.Properties.Appearance.Options.UseFont = true;
            this.textEditTime13_14.Properties.Appearance.Options.UseForeColor = true;
            this.textEditTime13_14.Properties.Appearance.Options.UseTextOptions = true;
            this.textEditTime13_14.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.textEditTime13_14.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.textEditTime13_14.Properties.Mask.EditMask = "n0";
            this.textEditTime13_14.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEditTime13_14.Properties.NullText = "0";
            this.textEditTime13_14.Size = new System.Drawing.Size(96, 24);
            this.textEditTime13_14.TabIndex = 40;
            // 
            // textEditTime12_13
            // 
            this.textEditTime12_13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textEditTime12_13.EditValue = "97/435";
            this.textEditTime12_13.Location = new System.Drawing.Point(209, 131);
            this.textEditTime12_13.Name = "textEditTime12_13";
            this.textEditTime12_13.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.textEditTime12_13.Properties.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.textEditTime12_13.Properties.Appearance.Options.UseFont = true;
            this.textEditTime12_13.Properties.Appearance.Options.UseForeColor = true;
            this.textEditTime12_13.Properties.Appearance.Options.UseTextOptions = true;
            this.textEditTime12_13.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.textEditTime12_13.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.textEditTime12_13.Properties.Mask.EditMask = "n0";
            this.textEditTime12_13.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEditTime12_13.Properties.NullText = "0";
            this.textEditTime12_13.Size = new System.Drawing.Size(96, 24);
            this.textEditTime12_13.TabIndex = 39;
            // 
            // textEditTime9_11
            // 
            this.textEditTime9_11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textEditTime9_11.EditValue = "145/300";
            this.textEditTime9_11.Location = new System.Drawing.Point(209, 103);
            this.textEditTime9_11.Name = "textEditTime9_11";
            this.textEditTime9_11.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.textEditTime9_11.Properties.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.textEditTime9_11.Properties.Appearance.Options.UseFont = true;
            this.textEditTime9_11.Properties.Appearance.Options.UseForeColor = true;
            this.textEditTime9_11.Properties.Appearance.Options.UseTextOptions = true;
            this.textEditTime9_11.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.textEditTime9_11.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.textEditTime9_11.Properties.Mask.EditMask = "n0";
            this.textEditTime9_11.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEditTime9_11.Properties.NullText = "0";
            this.textEditTime9_11.Size = new System.Drawing.Size(96, 24);
            this.textEditTime9_11.TabIndex = 38;
            // 
            // textEditTime9_9_30
            // 
            this.textEditTime9_9_30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textEditTime9_9_30.EditValue = "80/155";
            this.textEditTime9_9_30.Location = new System.Drawing.Point(209, 74);
            this.textEditTime9_9_30.Name = "textEditTime9_9_30";
            this.textEditTime9_9_30.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.textEditTime9_9_30.Properties.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.textEditTime9_9_30.Properties.Appearance.Options.UseFont = true;
            this.textEditTime9_9_30.Properties.Appearance.Options.UseForeColor = true;
            this.textEditTime9_9_30.Properties.Appearance.Options.UseTextOptions = true;
            this.textEditTime9_9_30.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.textEditTime9_9_30.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.textEditTime9_9_30.Properties.Mask.EditMask = "n0";
            this.textEditTime9_9_30.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEditTime9_9_30.Properties.NullText = "0";
            this.textEditTime9_9_30.Size = new System.Drawing.Size(96, 24);
            this.textEditTime9_9_30.TabIndex = 37;
            // 
            // lblOvertime
            // 
            this.lblOvertime.AutoSize = true;
            this.lblOvertime.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblOvertime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOvertime.Location = new System.Drawing.Point(4, 244);
            this.lblOvertime.Name = "lblOvertime";
            this.lblOvertime.Size = new System.Drawing.Size(198, 28);
            this.lblOvertime.TabIndex = 21;
            this.lblOvertime.Text = "Overtime";
            this.lblOvertime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(415, 1);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(98, 41);
            this.label17.TabIndex = 3;
            this.label17.Text = "Chênh lệch";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(312, 1);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(96, 41);
            this.label13.TabIndex = 2;
            this.label13.Text = "Thực tế";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(209, 1);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(96, 41);
            this.label12.TabIndex = 1;
            this.label12.Text = "Kế hoạch";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(4, 1);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(198, 41);
            this.label11.TabIndex = 0;
            this.label11.Text = "Thời gian";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(4, 43);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(198, 27);
            this.label18.TabIndex = 4;
            this.label18.Text = "8:05 ~ 9:00";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(4, 71);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(198, 28);
            this.label19.TabIndex = 5;
            this.label19.Text = "9:00 ~ 9:50";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ThucTe_8
            // 
            this.ThucTe_8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ThucTe_8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ThucTe_8.ForeColor = System.Drawing.Color.Blue;
            this.ThucTe_8.Location = new System.Drawing.Point(312, 43);
            this.ThucTe_8.Name = "ThucTe_8";
            this.ThucTe_8.Size = new System.Drawing.Size(96, 27);
            this.ThucTe_8.TabIndex = 7;
            this.ThucTe_8.Text = "0";
            this.ThucTe_8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(4, 100);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(198, 27);
            this.label20.TabIndex = 8;
            this.label20.Text = "10:00 ~ 11:45";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ThucTe_9
            // 
            this.ThucTe_9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ThucTe_9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ThucTe_9.ForeColor = System.Drawing.Color.Blue;
            this.ThucTe_9.Location = new System.Drawing.Point(312, 71);
            this.ThucTe_9.Name = "ThucTe_9";
            this.ThucTe_9.Size = new System.Drawing.Size(96, 28);
            this.ThucTe_9.TabIndex = 10;
            this.ThucTe_9.Text = "0";
            this.ThucTe_9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ThucTe_940
            // 
            this.ThucTe_940.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ThucTe_940.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ThucTe_940.ForeColor = System.Drawing.Color.Blue;
            this.ThucTe_940.Location = new System.Drawing.Point(312, 100);
            this.ThucTe_940.Name = "ThucTe_940";
            this.ThucTe_940.Size = new System.Drawing.Size(96, 27);
            this.ThucTe_940.TabIndex = 12;
            this.ThucTe_940.Text = "0";
            this.ThucTe_940.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ThucTe_12
            // 
            this.ThucTe_12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ThucTe_12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ThucTe_12.ForeColor = System.Drawing.Color.Blue;
            this.ThucTe_12.Location = new System.Drawing.Point(312, 128);
            this.ThucTe_12.Name = "ThucTe_12";
            this.ThucTe_12.Size = new System.Drawing.Size(96, 30);
            this.ThucTe_12.TabIndex = 14;
            this.ThucTe_12.Text = "0";
            this.ThucTe_12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ThucTe_13
            // 
            this.ThucTe_13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ThucTe_13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ThucTe_13.ForeColor = System.Drawing.Color.Blue;
            this.ThucTe_13.Location = new System.Drawing.Point(312, 159);
            this.ThucTe_13.Name = "ThucTe_13";
            this.ThucTe_13.Size = new System.Drawing.Size(96, 27);
            this.ThucTe_13.TabIndex = 16;
            this.ThucTe_13.Text = "0";
            this.ThucTe_13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(4, 128);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(198, 30);
            this.label32.TabIndex = 17;
            this.label32.Text = "12:30~ 13:30";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(4, 159);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(198, 27);
            this.label33.TabIndex = 18;
            this.label33.Text = "13:30 ~ 14:50";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(4, 187);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(198, 27);
            this.label34.TabIndex = 19;
            this.label34.Text = "14:50 ~ 16:00";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(4, 215);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(198, 28);
            this.label35.TabIndex = 20;
            this.label35.Text = "16:00 ~ 16:55";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ThucTe_14
            // 
            this.ThucTe_14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ThucTe_14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ThucTe_14.ForeColor = System.Drawing.Color.Blue;
            this.ThucTe_14.Location = new System.Drawing.Point(312, 187);
            this.ThucTe_14.Name = "ThucTe_14";
            this.ThucTe_14.Size = new System.Drawing.Size(96, 27);
            this.ThucTe_14.TabIndex = 24;
            this.ThucTe_14.Text = "0";
            this.ThucTe_14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ThucTe_16
            // 
            this.ThucTe_16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ThucTe_16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ThucTe_16.ForeColor = System.Drawing.Color.Blue;
            this.ThucTe_16.Location = new System.Drawing.Point(312, 215);
            this.ThucTe_16.Name = "ThucTe_16";
            this.ThucTe_16.Size = new System.Drawing.Size(96, 28);
            this.ThucTe_16.TabIndex = 25;
            this.ThucTe_16.Text = "0";
            this.ThucTe_16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ThucTe_Overtime
            // 
            this.ThucTe_Overtime.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ThucTe_Overtime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ThucTe_Overtime.ForeColor = System.Drawing.Color.Blue;
            this.ThucTe_Overtime.Location = new System.Drawing.Point(312, 244);
            this.ThucTe_Overtime.Name = "ThucTe_Overtime";
            this.ThucTe_Overtime.Size = new System.Drawing.Size(96, 28);
            this.ThucTe_Overtime.TabIndex = 26;
            this.ThucTe_Overtime.Text = "0";
            this.ThucTe_Overtime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ChenhLech8
            // 
            this.ChenhLech8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ChenhLech8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChenhLech8.ForeColor = System.Drawing.Color.Blue;
            this.ChenhLech8.Location = new System.Drawing.Point(415, 43);
            this.ChenhLech8.Name = "ChenhLech8";
            this.ChenhLech8.Size = new System.Drawing.Size(98, 27);
            this.ChenhLech8.TabIndex = 28;
            this.ChenhLech8.Text = "0";
            this.ChenhLech8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ChenhLech9
            // 
            this.ChenhLech9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ChenhLech9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChenhLech9.ForeColor = System.Drawing.Color.Blue;
            this.ChenhLech9.Location = new System.Drawing.Point(415, 71);
            this.ChenhLech9.Name = "ChenhLech9";
            this.ChenhLech9.Size = new System.Drawing.Size(98, 28);
            this.ChenhLech9.TabIndex = 29;
            this.ChenhLech9.Text = "0";
            this.ChenhLech9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ChenhLech940
            // 
            this.ChenhLech940.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ChenhLech940.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChenhLech940.ForeColor = System.Drawing.Color.Blue;
            this.ChenhLech940.Location = new System.Drawing.Point(415, 100);
            this.ChenhLech940.Name = "ChenhLech940";
            this.ChenhLech940.Size = new System.Drawing.Size(98, 27);
            this.ChenhLech940.TabIndex = 30;
            this.ChenhLech940.Text = "0";
            this.ChenhLech940.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ChenhLech12
            // 
            this.ChenhLech12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ChenhLech12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChenhLech12.ForeColor = System.Drawing.Color.Blue;
            this.ChenhLech12.Location = new System.Drawing.Point(415, 128);
            this.ChenhLech12.Name = "ChenhLech12";
            this.ChenhLech12.Size = new System.Drawing.Size(98, 30);
            this.ChenhLech12.TabIndex = 31;
            this.ChenhLech12.Text = "0";
            this.ChenhLech12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ChenhLech13
            // 
            this.ChenhLech13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ChenhLech13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChenhLech13.ForeColor = System.Drawing.Color.Blue;
            this.ChenhLech13.Location = new System.Drawing.Point(415, 159);
            this.ChenhLech13.Name = "ChenhLech13";
            this.ChenhLech13.Size = new System.Drawing.Size(98, 27);
            this.ChenhLech13.TabIndex = 32;
            this.ChenhLech13.Text = "0";
            this.ChenhLech13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ChenhLech14
            // 
            this.ChenhLech14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ChenhLech14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChenhLech14.ForeColor = System.Drawing.Color.Blue;
            this.ChenhLech14.Location = new System.Drawing.Point(415, 187);
            this.ChenhLech14.Name = "ChenhLech14";
            this.ChenhLech14.Size = new System.Drawing.Size(98, 27);
            this.ChenhLech14.TabIndex = 33;
            this.ChenhLech14.Text = "0";
            this.ChenhLech14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ChenhLech16
            // 
            this.ChenhLech16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ChenhLech16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChenhLech16.ForeColor = System.Drawing.Color.Blue;
            this.ChenhLech16.Location = new System.Drawing.Point(415, 215);
            this.ChenhLech16.Name = "ChenhLech16";
            this.ChenhLech16.Size = new System.Drawing.Size(98, 28);
            this.ChenhLech16.TabIndex = 34;
            this.ChenhLech16.Text = "0";
            this.ChenhLech16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ChenhLechOvertime
            // 
            this.ChenhLechOvertime.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ChenhLechOvertime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChenhLechOvertime.ForeColor = System.Drawing.Color.Blue;
            this.ChenhLechOvertime.Location = new System.Drawing.Point(415, 244);
            this.ChenhLechOvertime.Name = "ChenhLechOvertime";
            this.ChenhLechOvertime.Size = new System.Drawing.Size(98, 28);
            this.ChenhLechOvertime.TabIndex = 35;
            this.ChenhLechOvertime.Text = "0";
            this.ChenhLechOvertime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textEditTime8_9
            // 
            this.textEditTime8_9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textEditTime8_9.EditValue = "75/75";
            this.textEditTime8_9.Location = new System.Drawing.Point(209, 46);
            this.textEditTime8_9.Name = "textEditTime8_9";
            this.textEditTime8_9.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.textEditTime8_9.Properties.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.textEditTime8_9.Properties.Appearance.Options.UseFont = true;
            this.textEditTime8_9.Properties.Appearance.Options.UseForeColor = true;
            this.textEditTime8_9.Properties.Appearance.Options.UseTextOptions = true;
            this.textEditTime8_9.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.textEditTime8_9.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.textEditTime8_9.Properties.Mask.EditMask = "n0";
            this.textEditTime8_9.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEditTime8_9.Properties.NullText = "0";
            this.textEditTime8_9.Size = new System.Drawing.Size(96, 24);
            this.textEditTime8_9.TabIndex = 36;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.tableLayoutPanel8);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel8.Location = new System.Drawing.Point(0, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(593, 293);
            this.panel8.TabIndex = 4;
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 2;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36.42496F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 63.57504F));
            this.tableLayoutPanel8.Controls.Add(this.labelBalenced, 0, 3);
            this.tableLayoutPanel8.Controls.Add(this.label3, 0, 2);
            this.tableLayoutPanel8.Controls.Add(this.lblBalenced, 1, 3);
            this.tableLayoutPanel8.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.tableLayoutPanel9, 1, 1);
            this.tableLayoutPanel8.Controls.Add(this.label5, 0, 1);
            this.tableLayoutPanel8.Controls.Add(this.lblSetPlan, 1, 2);
            this.tableLayoutPanel8.Controls.Add(this.lblModelName, 1, 0);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 4;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 51.65563F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 48.34437F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 79F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(593, 293);
            this.tableLayoutPanel8.TabIndex = 44;
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 35F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(210, 73);
            this.label2.TabIndex = 7;
            this.label2.Text = "Model:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 2;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 43.70079F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 56.29921F));
            this.tableLayoutPanel9.Controls.Add(this.progressBar1, 1, 0);
            this.tableLayoutPanel9.Controls.Add(this.lblActual, 0, 0);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(219, 76);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 1;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(371, 62);
            this.tableLayoutPanel9.TabIndex = 6;
            // 
            // lblModelName
            // 
            this.lblModelName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblModelName.Font = new System.Drawing.Font("Microsoft Sans Serif", 35F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModelName.Location = new System.Drawing.Point(219, 0);
            this.lblModelName.Name = "lblModelName";
            this.lblModelName.Size = new System.Drawing.Size(371, 73);
            this.lblModelName.TabIndex = 22;
            this.lblModelName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.tableLayoutPanel1);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(0, 370);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1130, 508);
            this.panel7.TabIndex = 2;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel1.Controls.Add(this.panel11, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel15, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel13, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel16, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel9, 4, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1130, 508);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.panel20);
            this.panel11.Controls.Add(this.panel19);
            this.panel11.Controls.Add(this.panel12);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel11.Location = new System.Drawing.Point(398, 3);
            this.panel11.Name = "panel11";
            this.panel11.Padding = new System.Windows.Forms.Padding(35, 15, 35, 0);
            this.panel11.Size = new System.Drawing.Size(333, 502);
            this.panel11.TabIndex = 1;
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.lblOperatorWip23);
            this.panel20.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel20.Location = new System.Drawing.Point(35, 440);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(263, 43);
            this.panel20.TabIndex = 12;
            // 
            // lblOperatorWip23
            // 
            this.lblOperatorWip23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblOperatorWip23.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOperatorWip23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblOperatorWip23.Location = new System.Drawing.Point(0, 0);
            this.lblOperatorWip23.Name = "lblOperatorWip23";
            this.lblOperatorWip23.Size = new System.Drawing.Size(263, 43);
            this.lblOperatorWip23.TabIndex = 9;
            this.lblOperatorWip23.Text = "Operator:";
            this.lblOperatorWip23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.pictureBox2);
            this.panel19.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel19.Location = new System.Drawing.Point(35, 356);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(263, 84);
            this.panel19.TabIndex = 11;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox2.Image = global::IndicateReport.Properties.Resources.Employee;
            this.pictureBox2.Location = new System.Drawing.Point(99, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(72, 84);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // panel12
            // 
            this.panel12.BackgroundImage = global::IndicateReport.Properties.Resources._3938620_lcd_tv_monitor;
            this.panel12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel12.Controls.Add(this.tableLayoutPanel11);
            this.panel12.Controls.Add(this.tableLayoutPanel3);
            this.panel12.Controls.Add(this.lblProcessWip23);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel12.Location = new System.Drawing.Point(35, 15);
            this.panel12.Name = "panel12";
            this.panel12.Padding = new System.Windows.Forms.Padding(20);
            this.panel12.Size = new System.Drawing.Size(263, 341);
            this.panel12.TabIndex = 7;
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 2;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Controls.Add(this.lblTotalNGWip23, 1, 0);
            this.tableLayoutPanel11.Controls.Add(this.label9, 0, 0);
            this.tableLayoutPanel11.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel11.Location = new System.Drawing.Point(20, 200);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 1;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(223, 69);
            this.tableLayoutPanel11.TabIndex = 2;
            // 
            // lblTotalNGWip23
            // 
            this.lblTotalNGWip23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTotalNGWip23.Font = new System.Drawing.Font("DS-Digital", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalNGWip23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblTotalNGWip23.Location = new System.Drawing.Point(114, 0);
            this.lblTotalNGWip23.Name = "lblTotalNGWip23";
            this.lblTotalNGWip23.Size = new System.Drawing.Size(106, 69);
            this.lblTotalNGWip23.TabIndex = 6;
            this.lblTotalNGWip23.Text = "0 %";
            this.lblTotalNGWip23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label9.Location = new System.Drawing.Point(3, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(105, 69);
            this.label9.TabIndex = 4;
            this.label9.Text = "% NG:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 52.43903F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 47.56097F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 106F));
            this.tableLayoutPanel3.Controls.Add(this.lblNotGoodWip23, 2, 1);
            this.tableLayoutPanel3.Controls.Add(this.lblPassWip23, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.lblTotalWip23, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.label14, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.label15, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label16, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(20, 71);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(223, 129);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // lblNotGoodWip23
            // 
            this.lblNotGoodWip23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNotGoodWip23.Font = new System.Drawing.Font("DS-Digital", 39.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNotGoodWip23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblNotGoodWip23.Location = new System.Drawing.Point(119, 64);
            this.lblNotGoodWip23.Name = "lblNotGoodWip23";
            this.lblNotGoodWip23.Size = new System.Drawing.Size(101, 65);
            this.lblNotGoodWip23.TabIndex = 5;
            this.lblNotGoodWip23.Text = "0";
            this.lblNotGoodWip23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPassWip23
            // 
            this.lblPassWip23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPassWip23.Font = new System.Drawing.Font("DS-Digital", 39.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPassWip23.ForeColor = System.Drawing.Color.Green;
            this.lblPassWip23.Location = new System.Drawing.Point(64, 64);
            this.lblPassWip23.Name = "lblPassWip23";
            this.lblPassWip23.Size = new System.Drawing.Size(49, 65);
            this.lblPassWip23.TabIndex = 4;
            this.lblPassWip23.Text = "0";
            this.lblPassWip23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTotalWip23
            // 
            this.lblTotalWip23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTotalWip23.Font = new System.Drawing.Font("DS-Digital", 39.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalWip23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblTotalWip23.Location = new System.Drawing.Point(3, 64);
            this.lblTotalWip23.Name = "lblTotalWip23";
            this.lblTotalWip23.Size = new System.Drawing.Size(55, 65);
            this.lblTotalWip23.TabIndex = 3;
            this.lblTotalWip23.Text = "0";
            this.lblTotalWip23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label14.Location = new System.Drawing.Point(119, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(101, 64);
            this.label14.TabIndex = 2;
            this.label14.Text = "NG";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Green;
            this.label15.Location = new System.Drawing.Point(64, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(49, 64);
            this.label15.TabIndex = 1;
            this.label15.Text = "PASS";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label16.Location = new System.Drawing.Point(3, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(55, 64);
            this.label16.TabIndex = 0;
            this.label16.Text = "TOTAL";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblProcessWip23
            // 
            this.lblProcessWip23.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblProcessWip23.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProcessWip23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblProcessWip23.Location = new System.Drawing.Point(20, 20);
            this.lblProcessWip23.Name = "lblProcessWip23";
            this.lblProcessWip23.Size = new System.Drawing.Size(223, 51);
            this.lblProcessWip23.TabIndex = 0;
            this.lblProcessWip23.Text = "Process";
            this.lblProcessWip23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.pictureBox4);
            this.panel15.Location = new System.Drawing.Point(342, 3);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(50, 254);
            this.panel15.TabIndex = 3;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox4.Image = global::IndicateReport.Properties.Resources.go_next_64;
            this.pictureBox4.Location = new System.Drawing.Point(0, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(50, 254);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.panel21);
            this.panel13.Controls.Add(this.panel22);
            this.panel13.Controls.Add(this.panel14);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel13.Location = new System.Drawing.Point(3, 3);
            this.panel13.Name = "panel13";
            this.panel13.Padding = new System.Windows.Forms.Padding(35, 15, 35, 0);
            this.panel13.Size = new System.Drawing.Size(333, 502);
            this.panel13.TabIndex = 2;
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.lblOperatorWip21);
            this.panel21.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel21.Location = new System.Drawing.Point(35, 440);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(263, 43);
            this.panel21.TabIndex = 14;
            // 
            // lblOperatorWip21
            // 
            this.lblOperatorWip21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblOperatorWip21.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOperatorWip21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblOperatorWip21.Location = new System.Drawing.Point(0, 0);
            this.lblOperatorWip21.Name = "lblOperatorWip21";
            this.lblOperatorWip21.Size = new System.Drawing.Size(263, 43);
            this.lblOperatorWip21.TabIndex = 9;
            this.lblOperatorWip21.Text = "Operator:";
            this.lblOperatorWip21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.pictureBox3);
            this.panel22.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel22.Location = new System.Drawing.Point(35, 356);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(263, 84);
            this.panel22.TabIndex = 13;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox3.Image = global::IndicateReport.Properties.Resources.Employee;
            this.pictureBox3.Location = new System.Drawing.Point(88, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(72, 84);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // panel14
            // 
            this.panel14.BackgroundImage = global::IndicateReport.Properties.Resources._3938620_lcd_tv_monitor;
            this.panel14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel14.Controls.Add(this.tableLayoutPanel12);
            this.panel14.Controls.Add(this.tableLayoutPanel4);
            this.panel14.Controls.Add(this.lblProcessWip21);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel14.Location = new System.Drawing.Point(35, 15);
            this.panel14.Name = "panel14";
            this.panel14.Padding = new System.Windows.Forms.Padding(20);
            this.panel14.Size = new System.Drawing.Size(263, 341);
            this.panel14.TabIndex = 7;
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.ColumnCount = 2;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel12.Controls.Add(this.lblTotalNGWip21, 1, 0);
            this.tableLayoutPanel12.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel12.Location = new System.Drawing.Point(20, 200);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 1;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(223, 69);
            this.tableLayoutPanel12.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label4.Location = new System.Drawing.Point(3, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 69);
            this.label4.TabIndex = 3;
            this.label4.Text = "% NG:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblTotalNGWip21
            // 
            this.lblTotalNGWip21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTotalNGWip21.Font = new System.Drawing.Font("DS-Digital", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalNGWip21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblTotalNGWip21.Location = new System.Drawing.Point(114, 0);
            this.lblTotalNGWip21.Name = "lblTotalNGWip21";
            this.lblTotalNGWip21.Size = new System.Drawing.Size(106, 69);
            this.lblTotalNGWip21.TabIndex = 7;
            this.lblTotalNGWip21.Text = "0 %";
            this.lblTotalNGWip21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 3;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 51.17647F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 48.82353F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel4.Controls.Add(this.lblNotGoodWip21, 2, 1);
            this.tableLayoutPanel4.Controls.Add(this.lblPassWip21, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.lblTotalWip21, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.label23, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.label24, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.label25, 0, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(20, 71);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(223, 129);
            this.tableLayoutPanel4.TabIndex = 1;
            // 
            // lblNotGoodWip21
            // 
            this.lblNotGoodWip21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNotGoodWip21.Font = new System.Drawing.Font("DS-Digital", 39.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNotGoodWip21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblNotGoodWip21.Location = new System.Drawing.Point(125, 64);
            this.lblNotGoodWip21.Name = "lblNotGoodWip21";
            this.lblNotGoodWip21.Size = new System.Drawing.Size(95, 65);
            this.lblNotGoodWip21.TabIndex = 5;
            this.lblNotGoodWip21.Text = "0";
            this.lblNotGoodWip21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPassWip21
            // 
            this.lblPassWip21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPassWip21.Font = new System.Drawing.Font("DS-Digital", 39.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPassWip21.ForeColor = System.Drawing.Color.Green;
            this.lblPassWip21.Location = new System.Drawing.Point(65, 64);
            this.lblPassWip21.Name = "lblPassWip21";
            this.lblPassWip21.Size = new System.Drawing.Size(54, 65);
            this.lblPassWip21.TabIndex = 4;
            this.lblPassWip21.Text = "0";
            this.lblPassWip21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTotalWip21
            // 
            this.lblTotalWip21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTotalWip21.Font = new System.Drawing.Font("DS-Digital", 39.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalWip21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblTotalWip21.Location = new System.Drawing.Point(3, 64);
            this.lblTotalWip21.Name = "lblTotalWip21";
            this.lblTotalWip21.Size = new System.Drawing.Size(56, 65);
            this.lblTotalWip21.TabIndex = 3;
            this.lblTotalWip21.Text = "0";
            this.lblTotalWip21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label23.Location = new System.Drawing.Point(125, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(95, 64);
            this.label23.TabIndex = 2;
            this.label23.Text = "NG";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Green;
            this.label24.Location = new System.Drawing.Point(65, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(54, 64);
            this.label24.TabIndex = 1;
            this.label24.Text = "PASS";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label25.Location = new System.Drawing.Point(3, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(56, 64);
            this.label25.TabIndex = 0;
            this.label25.Text = "TOTAL";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblProcessWip21
            // 
            this.lblProcessWip21.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblProcessWip21.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProcessWip21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblProcessWip21.Location = new System.Drawing.Point(20, 20);
            this.lblProcessWip21.Name = "lblProcessWip21";
            this.lblProcessWip21.Size = new System.Drawing.Size(223, 51);
            this.lblProcessWip21.TabIndex = 0;
            this.lblProcessWip21.Text = "Process";
            this.lblProcessWip21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.pictureBox5);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel16.Location = new System.Drawing.Point(737, 3);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(50, 254);
            this.panel16.TabIndex = 4;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox5.Image = global::IndicateReport.Properties.Resources.go_next_64;
            this.pictureBox5.Location = new System.Drawing.Point(0, 0);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(50, 254);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox5.TabIndex = 1;
            this.pictureBox5.TabStop = false;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.panel18);
            this.panel9.Controls.Add(this.panel17);
            this.panel9.Controls.Add(this.panel10);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(793, 3);
            this.panel9.Name = "panel9";
            this.panel9.Padding = new System.Windows.Forms.Padding(35, 15, 35, 0);
            this.panel9.Size = new System.Drawing.Size(334, 502);
            this.panel9.TabIndex = 0;
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.lblOperatorWip22);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel18.Location = new System.Drawing.Point(35, 440);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(264, 43);
            this.panel18.TabIndex = 8;
            // 
            // lblOperatorWip22
            // 
            this.lblOperatorWip22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblOperatorWip22.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOperatorWip22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblOperatorWip22.Location = new System.Drawing.Point(0, 0);
            this.lblOperatorWip22.Name = "lblOperatorWip22";
            this.lblOperatorWip22.Size = new System.Drawing.Size(264, 43);
            this.lblOperatorWip22.TabIndex = 5;
            this.lblOperatorWip22.Text = "Operator:";
            this.lblOperatorWip22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.pictureBox1);
            this.panel17.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel17.Location = new System.Drawing.Point(35, 356);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(264, 84);
            this.panel17.TabIndex = 7;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Image = global::IndicateReport.Properties.Resources.Employee;
            this.pictureBox1.Location = new System.Drawing.Point(99, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(73, 84);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel10
            // 
            this.panel10.BackgroundImage = global::IndicateReport.Properties.Resources._3938620_lcd_tv_monitor;
            this.panel10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel10.Controls.Add(this.tableLayoutPanel10);
            this.panel10.Controls.Add(this.tableLayoutPanel2);
            this.panel10.Controls.Add(this.lblProcessWip22);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel10.Location = new System.Drawing.Point(35, 15);
            this.panel10.Name = "panel10";
            this.panel10.Padding = new System.Windows.Forms.Padding(20);
            this.panel10.Size = new System.Drawing.Size(264, 341);
            this.panel10.TabIndex = 3;
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 2;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.Controls.Add(this.lblTotalNGWip22, 1, 0);
            this.tableLayoutPanel10.Controls.Add(this.label10, 0, 0);
            this.tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(20, 200);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 1;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(224, 69);
            this.tableLayoutPanel10.TabIndex = 5;
            // 
            // lblTotalNGWip22
            // 
            this.lblTotalNGWip22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTotalNGWip22.Font = new System.Drawing.Font("DS-Digital", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalNGWip22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblTotalNGWip22.Location = new System.Drawing.Point(115, 0);
            this.lblTotalNGWip22.Name = "lblTotalNGWip22";
            this.lblTotalNGWip22.Size = new System.Drawing.Size(106, 69);
            this.lblTotalNGWip22.TabIndex = 7;
            this.lblTotalNGWip22.Text = "0 %";
            this.lblTotalNGWip22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label10
            // 
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label10.Location = new System.Drawing.Point(3, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(106, 69);
            this.label10.TabIndex = 4;
            this.label10.Text = "% NG:";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 51.51515F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 48.48485F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 106F));
            this.tableLayoutPanel2.Controls.Add(this.lblNotGoodWip22, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.lblPassWip22, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.lblTotalWip22, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label6, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.label7, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label8, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(20, 71);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(224, 129);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // lblNotGoodWip22
            // 
            this.lblNotGoodWip22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNotGoodWip22.Font = new System.Drawing.Font("DS-Digital", 39.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNotGoodWip22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblNotGoodWip22.Location = new System.Drawing.Point(120, 64);
            this.lblNotGoodWip22.Name = "lblNotGoodWip22";
            this.lblNotGoodWip22.Size = new System.Drawing.Size(101, 65);
            this.lblNotGoodWip22.TabIndex = 5;
            this.lblNotGoodWip22.Text = "0";
            this.lblNotGoodWip22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPassWip22
            // 
            this.lblPassWip22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPassWip22.Font = new System.Drawing.Font("DS-Digital", 39.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPassWip22.ForeColor = System.Drawing.Color.Green;
            this.lblPassWip22.Location = new System.Drawing.Point(63, 64);
            this.lblPassWip22.Name = "lblPassWip22";
            this.lblPassWip22.Size = new System.Drawing.Size(51, 65);
            this.lblPassWip22.TabIndex = 4;
            this.lblPassWip22.Text = "0";
            this.lblPassWip22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTotalWip22
            // 
            this.lblTotalWip22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTotalWip22.Font = new System.Drawing.Font("DS-Digital", 39.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalWip22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblTotalWip22.Location = new System.Drawing.Point(3, 64);
            this.lblTotalWip22.Name = "lblTotalWip22";
            this.lblTotalWip22.Size = new System.Drawing.Size(54, 65);
            this.lblTotalWip22.TabIndex = 3;
            this.lblTotalWip22.Text = "0";
            this.lblTotalWip22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label6.Location = new System.Drawing.Point(120, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 64);
            this.label6.TabIndex = 2;
            this.label6.Text = "NG";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Green;
            this.label7.Location = new System.Drawing.Point(63, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 64);
            this.label7.TabIndex = 1;
            this.label7.Text = "PASS";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label8.Location = new System.Drawing.Point(3, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 64);
            this.label8.TabIndex = 0;
            this.label8.Text = "TOTAL";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblProcessWip22
            // 
            this.lblProcessWip22.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblProcessWip22.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProcessWip22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblProcessWip22.Location = new System.Drawing.Point(20, 20);
            this.lblProcessWip22.Name = "lblProcessWip22";
            this.lblProcessWip22.Size = new System.Drawing.Size(224, 51);
            this.lblProcessWip22.TabIndex = 0;
            this.lblProcessWip22.Text = "Process";
            this.lblProcessWip22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timerRunAuto
            // 
            this.timerRunAuto.Enabled = true;
            this.timerRunAuto.Tick += new System.EventHandler(this.timerRunAuto_Tick);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1130, 878);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panelContainer);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.Name = "FormMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Indecate Report";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit1.Properties)).EndInit();
            this.panelContainer.ResumeLayout(false);
            this.panel26.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textEditOvertime.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditTime16_17.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditTime14_16.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditTime13_14.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditTime12_13.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditTime9_11.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditTime9_9_30.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditTime8_9.Properties)).EndInit();
            this.panel8.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel9.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel20.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel12.ResumeLayout(false);
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel13.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel14.ResumeLayout(false);
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel9.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel10.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblSetPlan;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblActual;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Label labelBalenced;
        private System.Windows.Forms.Label lblBalenced;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panelContainer;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label lblOperatorWip22;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label lblNotGoodWip22;
        private System.Windows.Forms.Label lblPassWip22;
        private System.Windows.Forms.Label lblTotalWip22;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblProcessWip22;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label lblOperatorWip23;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label lblNotGoodWip23;
        private System.Windows.Forms.Label lblPassWip23;
        private System.Windows.Forms.Label lblTotalWip23;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lblProcessWip23;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label lblOperatorWip21;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label lblNotGoodWip21;
        private System.Windows.Forms.Label lblPassWip21;
        private System.Windows.Forms.Label lblTotalWip21;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label lblProcessWip21;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Timer timerRunAuto;
        private System.Windows.Forms.Label lblTotalNGWip23;
        private System.Windows.Forms.Label lblTotalNGWip21;
        private System.Windows.Forms.Label lblTotalNGWip22;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private DevExpress.XtraEditors.LookUpEdit lookUpEdit1;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label ThucTe_8;
        private System.Windows.Forms.Label lblModelName;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label ThucTe_9;
        private System.Windows.Forms.Label ThucTe_940;
        private System.Windows.Forms.Label ThucTe_12;
        private System.Windows.Forms.Label ThucTe_13;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label lblOvertime;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label ThucTe_14;
        private System.Windows.Forms.Label ThucTe_16;
        private System.Windows.Forms.Label ThucTe_Overtime;
        private System.Windows.Forms.Label ChenhLech8;
        private System.Windows.Forms.Label ChenhLech9;
        private System.Windows.Forms.Label ChenhLech940;
        private System.Windows.Forms.Label ChenhLech12;
        private System.Windows.Forms.Label ChenhLech13;
        private System.Windows.Forms.Label ChenhLech14;
        private System.Windows.Forms.Label ChenhLech16;
        private System.Windows.Forms.Label ChenhLechOvertime;
        private DevExpress.XtraEditors.TextEdit textEditTime8_9;
        private DevExpress.XtraEditors.TextEdit textEditOvertime;
        private DevExpress.XtraEditors.TextEdit textEditTime16_17;
        private DevExpress.XtraEditors.TextEdit textEditTime14_16;
        private DevExpress.XtraEditors.TextEdit textEditTime13_14;
        private DevExpress.XtraEditors.TextEdit textEditTime12_13;
        private DevExpress.XtraEditors.TextEdit textEditTime9_11;
        private DevExpress.XtraEditors.TextEdit textEditTime9_9_30;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
    }
}

